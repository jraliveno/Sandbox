def read_student_data():
    student_courses = {}

    while True:
        data = input("Enter student data (ID Course), or enter -1 to stop: ")

        if data == "-1":
            break

        try:
            student_id, course = data.split()
            student_id = int(student_id)

            if student_id not in student_courses:
                student_courses[student_id] = [course]
            else:
                student_courses[student_id].append(course)

        except ValueError:
            print("Invalid input format. Please enter data in the format 'ID Course'.")

    return student_courses


def print_student_courses(student_courses):
    for student_id, courses in student_courses.items():
        print(f"Student {student_id} is enrolled in courses: {', '.join(courses)}")


if __name__ == "__main__":
    student_courses = read_student_data()
    print_student_courses(student_courses)
