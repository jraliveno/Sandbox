class Node:
    def __init__(self, data):
        self.data = data
        self.next = None

class CircularList:
    def __init__(self):
        self.head = None

    def append(self, data):
        new_node = Node(data)
        if not self.head:
            self.head = new_node
            new_node.next = self.head
        else:
            current = self.head
            while current.next != self.head:
                current = current.next
            current.next = new_node
            new_node.next = self.head

    def eliminate_suitor(self, count):
        current = self.head
        prev = None

        while current.next != current:
            for _ in range(count - 1):
                prev = current
                current = current.next

            # get rid of the suitor
            if prev:
                prev.next = current.next
            else:
                self.head = current.next
                while current.next != self.head:
                    current = current.next
                current.next = self.head

            eliminated_suitor = current.data
            current = current.next

            print(f"Suitor {eliminated_suitor} eliminated. Continue counting from {current.data}")

        return current.data

def find_lucky_winner(num_suitors):
    circular_list = CircularList()

    for i in range(1, num_suitors + 1):
        circular_list.append(i)

    lucky_winner = circular_list.eliminate_suitor(3)
    print(f"\nSuitor {lucky_winner} is the lucky winner!")

if __name__ == "__main__":
    num_suitors = int(input("Enter the number of suitors: "))
    find_lucky_winner(num_suitors)
