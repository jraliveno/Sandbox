class Triangle:
    def __init__(self, side1=1.0, side2=1.0, side3=1.0):
        self._side1 = self._validate_and_set_side(side1)
        self._side2 = self._validate_and_set_side(side2)
        self._side3 = self._validate_and_set_side(side3)

    def _validate_and_set_side(self, value):
        if not isinstance(value, (int, float)):
            raise ValueError("Side must be a numeric value")
        if value <= 0:
            raise ValueError("Side length must be greater than 0")
        return value

    def get_area(self):
        s = (self._side1 + self._side2 + self._side3) / 2
        area_squared = s * (s - self._side1) * (s - self._side2) * (s - self._side3)
        area = self._sqrt(area_squared)
        return area

    def get_perimeter(self):
        perimeter = self._side1 + self._side2 + self._side3
        return perimeter

    def _sqrt(self, x):
        # Newton's method for square root approximation
        guess = x / 2
        while True:
            new_guess = (guess + x / guess) / 2
            if abs(new_guess - guess) < 1e-10:
                return new_guess
            guess = new_guess

    def __str__(self):
        return f"Triangle with sides: {self._side1}, {self._side2}, {self._side3}"

if __name__ == "__main__":
    # Create sample triangles
    triangle1 = Triangle(3, 4, 5)
    triangle2 = Triangle(1, 1, 1)
    triangle3 = Triangle()

    # test
    print("Triangle 1:")
    print(f"Area: {triangle1.get_area()}")
    print(f"Perimeter: {triangle1.get_perimeter()}")
    print(triangle1)

    print("\nTriangle 2:")
    print(f"Area: {triangle2.get_area()}")
    print(f"Perimeter: {triangle2.get_perimeter()}")
    print(triangle2)

    print("\nTriangle 3:")
    print(f"Area: {triangle3.get_area()}")
    print(f"Perimeter: {triangle3.get_perimeter()}")
    print(triangle3)
