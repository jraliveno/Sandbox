import time
import random

class Stopwatch:
    def __init__(self):
        self._start_time = None
        self._stop_time = None

    @property
    def start_time(self):
        return self._start_time

    @property
    def stop_time(self):
        return self._stop_time

    def start(self):
        self._start_time = time.time()

    def stop(self):
        self._stop_time = time.time()

    def get_elapsed_time(self):
        if self._start_time is None or self._stop_time is None:
            raise ValueError("Start and stop times must be set first.")
        return int((self._stop_time - self._start_time) * 1000)  # Convert to milliseconds

def bubble_sort(arr):
    n = len(arr)
    for i in range(n):
        for j in range(0, n-i-1):
            if arr[j] > arr[j+1]:
                arr[j], arr[j+1] = arr[j+1], arr[j]

# testing the stopwatch with bubble bort
if __name__ == "__main__":
    # generate a list of 100,000 random numbers
    numbers = [random.randint(1, 100000) for _ in range(100000)]

    stopwatch = Stopwatch()

    # start the stopwatch and perform the sorting
    stopwatch.start()
    bubble_sort(numbers)
    stopwatch.stop()

    # print the elapsed time
    elapsed_time = stopwatch.get_elapsed_time()
    print(f"Bubble Sort took {elapsed_time} milliseconds.")
