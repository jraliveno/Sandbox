def process_ratings_file(file_path):
    movie_ratings = {}

    with open(file_path, 'r') as file:
        lines = file.readlines()

    i = 0
    while i < len(lines):
        num_reviews = int(lines[i].strip())
        movie_title = lines[i + 1].strip()

        if movie_title not in movie_ratings:
            movie_ratings[movie_title] = {'total_rating': 0, 'num_reviews': 0}

        for j in range(num_reviews):
            rating = int(lines[i + 2 + j].strip())
            movie_ratings[movie_title]['total_rating'] += rating
            movie_ratings[movie_title]['num_reviews'] += 1

        i += 2 + num_reviews

    return movie_ratings

def print_movie_statistics(movie_ratings):
    for movie, data in movie_ratings.items():
        num_reviews = data['num_reviews']
        total_rating = data['total_rating']
        average_rating = total_rating / num_reviews if num_reviews > 0 else 0

        print(f"{movie}: {num_reviews} review{'s' if num_reviews > 1 else ''}, "
              f"average of {average_rating:.1f} / 5")

if __name__ == "__main__":
    file_path = "ratings.txt"  # Replace with the actual path to your ratings file
    ratings_data = process_ratings_file(file_path)
    print_movie_statistics(ratings_data)
