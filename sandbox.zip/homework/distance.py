# Get speed of the car
speed = float(input("Enter the speed of the car (in miles per hour): "))

# times to calculate the distance
times = [6, 10, 15]

# Calculate each time
for time in times:
    distance = speed * time
    print(f"The distance the car travels in {time} hours is {distance} miles.")
