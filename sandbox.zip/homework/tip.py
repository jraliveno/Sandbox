# Get the charge for food
food_charge = float(input("Enter the charge for food: $"))

# Calculate the tip (18 percent)
tip_percent = 18
tip_amount = (tip_percent / 100) * food_charge

# Calculate the sales tax (7 percent)
tax_percent = 7
tax_amount = (tax_percent / 100) * food_charge

# Calculating total amount
total_amount = food_charge + tip_amount + tax_amount

# amount and the total
print(f"Food Charge: ${food_charge:.2f}")
print(f"Tip ({tip_percent}%): ${tip_amount:.2f}")
print(f"Sales Tax ({tax_percent}%): ${tax_amount:.2f}")
print(f"Total Amount: ${total_amount:.2f}")
