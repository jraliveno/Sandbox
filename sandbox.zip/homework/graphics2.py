import turtle

# Create a Turtle screen
window = turtle.Screen()
window.bgcolor("white")

# Create a Turtle object
ring_turtle = turtle.Turtle()
ring_turtle.speed(1)  # Set the drawing speed (1 is slow, you can adjust it)

def draw_circle(color, radius, x, y):
    ring_turtle.penup()
    ring_turtle.pensize(4)
    ring_turtle.color(color)
    ring_turtle.fillcolor(color)
    ring_turtle.goto(x, y - radius)
    ring_turtle.pendown()
    ring_turtle.circle(radius)
    ring_turtle.end_fill()

# Define the positions and colors of the Olympic rings
ring_positions = [(-120, 0, "blue"), (0, 0, "black"), (120, 0, "red"), (-60, -60, "yellow"), (60, -60, "green")]
ring_radius = 45

# Draw the Olympic rings
for x, y, color in ring_positions:
    draw_circle(color, ring_radius, x, y)

