# ingredients
sugar_per_cookie = 1.5 / 48  # Cups of sugar per cookie
butter_per_cookie = 1 / 48   # Cups of butter per cookie
flour_per_cookie = 2.75 / 48  # Cups of flour per cookie

# The number of cookies the user wants to make
desired_cookies = int(input("How many cookies would you like to make? "))

# The required amounts of each ingredient
required_sugar = sugar_per_cookie * desired_cookies
required_butter = butter_per_cookie * desired_cookies
required_flour = flour_per_cookie * desired_cookies

# result
print(f"To make {desired_cookies} cookies, you will need:")
print(f"{required_sugar:.2f} cups of sugar")
print(f"{required_butter:.2f} cups of butter")
print(f"{required_flour:.2f} cups of flour")
