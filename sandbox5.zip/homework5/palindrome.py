def is_prime(n):
    if n < 2:
        return False
    for i in range(2, int(n**0.5) + 1):
        if n % i == 0:
            return False
    return True

def is_palindrome(n):
    return str(n) == str(n)[::-1]

def generate_palindrome_primes(limit):
    palindrome_primes = []
    num = 2  # Start with the first prime number

    while len(palindrome_primes) < limit:
        if is_prime(num) and is_palindrome(num):
            palindrome_primes.append(num)
        num += 1

    return palindrome_primes

def main():
    try:
        # generate the first 100 palindrome numbers
        palindromic_primes = generate_palindrome_primes(100)

        # transfer the palindrome numbers to output.txt
        with open('output.txt', 'w') as file:
            file.write(' '.join(map(str, palindromic_primes)))

        print("Palindromic primes have been written to output.txt.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
