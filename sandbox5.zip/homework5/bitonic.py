def binary_find_max(arr, low, high):
    if low == high:
        return low

    mid = (low + high) // 2

    if arr[mid] > arr[mid + 1] and arr[mid] > arr[mid - 1]:
        return mid
    elif arr[mid] < arr[mid + 1]:
        return binary_find_max(arr, mid + 1, high)
    else:
        return binary_find_max(arr, low, mid - 1)

def main():
    try:
        # get the user input for the list of numbers
        num_list = list(map(int, input("Enter a list of numbers separated by spaces: ").split()))

        # locate the index of the maximum value in the bitonic array
        max_index = binary_find_max(num_list, 0, len(num_list) - 1)

        if max_index != -1:
            print(f"Your list is bitonic with a maximum value of {num_list[max_index]}.")
        else:
            print("The list is not bitonic.")

    except ValueError:
        print("Invalid input. Please enter a valid list of numbers.")

if __name__ == "__main__":
    main()
