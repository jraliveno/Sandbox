def merge(list1, list2):
    merged_list = sorted(list1 + list2)
    return merged_list

def main():
    try:
        # get input for the first list of integers
        input_list1 = input("Enter list 1 : ")
        list1 = [int(x) for x in input_list1.split()]

        # Get user input for the second list of integers
        input_list2 = input("Enter list 2 : ")
        list2 = [int(x) for x in input_list2.split()]

        # merge and sort the lists
        merged_list = merge(list1, list2)

        # print the list
        print("The merged list is", ' '.join(map(str, merged_list)))
    except ValueError:
        print("Invalid input. Please enter integers.")

if __name__ == "__main__":
    main()
