def calc_checksum(digits):
    total = 0
    for i in range(12):
        if i % 2 == 0:
            total += int(digits[i])
        else:
            total += 3 * int(digits[i])
    checksum = 10 - (total % 10)
    return checksum if checksum < 10 else 0

def gen_isbn_13(first_12_digits):
    checksum = calc_checksum(first_12_digits)
    isbn_13 = first_12_digits + str(checksum)
    return isbn_13

def main():
    try:
        # get input for the first 12 digits of ISBN-13
        first_12 = input("Enter the first 12 digits of an ISBN-13 as a string: ")

        if len(first_12) == 12 and first_12.isdigit():
            isbn_13 = gen_isbn_13(first_12)
            print(f"The ISBN-13 number is {isbn_13}")
        else:
            print("Invalid input. Please enter 12 digits as a string.")
    except Exception as e:
        print(f"An error occurred: {e}")

if __name__ == "__main__":
    main()
