def is_markov_matrix(matrix):
    n = len(matrix)

    # check if the matrix is square
    if not all(len(row) == n for row in matrix):
        return False

    # check to see if each element is positive
    if not all(all(element >= 0 for element in row) for row in matrix):
        return False

    # check if the sum of elements in each column is 1
    column_sums = [sum(matrix[i][j] for i in range(n)) for j in range(n)]
    if not all(abs(sum - 1) < 1e-10 for sum in column_sums):
        return False

    return True

def main():
    try:
        # get input for the matrix
        n = int(input("Enter the size of the square matrix (n): "))
        print(f"Enter a {n}-by-{n} matrix row by row:")
        matrix = [[float(input()) for _ in range(n)] for _ in range(n)]

        # check if the matrix is a Markov matrix
        if is_markov_matrix(matrix):
            print("It is a Markov matrix")
        else:
            print("It is not a Markov matrix")
    except ValueError:
        print("Invalid input. Please enter valid numeric values.")

if __name__ == "__main__":
    main()
