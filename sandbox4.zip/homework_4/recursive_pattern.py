def m(i):
    if i == 1:
        return 1/3
    else:
        prev_term = m(i - 1)
        return prev_term + i / (2 * i + 1)

# test the function for i values from 1 to 10
for i in range(1, 11):
    result = m(i)
    print(f"m({i}) = {result}")
