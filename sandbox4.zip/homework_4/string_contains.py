def contains(haystack, needle):
    if len(needle) > len(haystack):
        return False
    if haystack.startswith(needle):
        return True
    return contains(haystack[1:], needle)

# testing cases
if __name__ == "__main__":
    # Test cases
    print(contains("Java programming", "ogr"))  # True
    print(contains("Java programming", "grammy"))  # False
    print(contains("Python is great", "is"))  # True
    print(contains("Recursive functions are fun", "funny"))  # False
