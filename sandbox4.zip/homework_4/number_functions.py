# Function to reverse an integer
def reverse(number):
    return int(str(number)[::-1])

# function that will calculate the sum of the digits in an integer
def sum_digits(number):
    return sum(int(digit) for digit in str(abs(number)))

# function that will calculate the pentagonal number for an input n
def pentagonal_number(n):
    return n * (3 * n - 1) // 2

def main():
    # test the reverse function
    num1 = 152
    reversed_num1 = reverse(num1)
    print(f"Reverse of {num1}: {reversed_num1}")

    # test the sum_digits function
    num2 = 234
    digit_sum2 = sum_digits(num2)
    print(f"Sum of digits in {num2}: {digit_sum2}")

    # test the pentagonal_number function
    n = 2
    pentagonal_n = pentagonal_number(n)
    print(f"Pentagonal Number for n={n}: {pentagonal_n}")

if __name__ == "__main__":
    main()
