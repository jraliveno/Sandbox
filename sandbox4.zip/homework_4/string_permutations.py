def get_permutations(input_string):
    if len(input_string) <= 1:
        return [input_string]

    char = input_string[0]
    permutations = get_permutations(input_string[1:])
    result = []

    for perm in permutations:
        for i in range(len(perm) + 1):
            result.append(perm[:i] + char + perm[i:])

    return result


def main():
    user_input = input("Enter a string: ")
    permutations = get_permutations(user_input)

    print("Permutations of", user_input, "are:")
    for perm in permutations:
        print(perm)


if __name__ == "__main__":
    main()
