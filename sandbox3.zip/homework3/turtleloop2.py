import turtle

turtle = turtle.Turtle()
turtle.speed(30)
turtle.pensize(3)

yellow = "yellow"
purple = "purple"

for i in range(500):
    if i % 2 == 0:
        turtle.pencolor(yellow)
    else:
        turtle.pencolor(purple)

    turtle.begin_fill()  # Start filling
    turtle.forward(i)
    turtle.left(91)
    turtle.end_fill()  # End filling

turtle.done()
