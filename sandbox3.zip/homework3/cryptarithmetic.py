def cryptarithmetic():
    for T in range(10):
        for O in range(10):
            for G in range(10):
                for D in range(10):
                    if len(set([T, O, G, D])) == 4:  # Check for unique values
                        TOO = T * 100 + O * 10 + O
                        GOOD = G * 1000 + O * 100 + O * 10 + D

                        if TOO + TOO + TOO + TOO == GOOD:
                            return T, O, G, D

    return None

solution = cryptarithmetic()

if solution:
    T, O, G, D = solution
    print(f'T = {T}, O = {O}, G = {G}, D = {D}')
    print(f'Solution: TOO + TOO + TOO + TOO = GOOD')
else:
    print("No solution found.")

