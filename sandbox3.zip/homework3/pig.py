import random


def computer_turn(score):
    turn_score = 0
    while turn_score < 20:
        roll = random.randint(1, 6)
        if roll == 1:
            return 0
        turn_score += roll
    return turn_score


human_score = 0
computer_score = 0

while human_score < 100 and computer_score < 100:
    print(f"Your score: {human_score}, Computer score: {computer_score}")

    user_input = input("Enter 'r' to roll or 'h' to hold: ")

    if user_input == 'r':
        roll = random.randint(1, 6)
        print(f"You rolled a {roll}")
        if roll == 1:
            human_score = 0
            print("Your turn is over. Computer's turn.")
        else:
            human_score += roll
    elif user_input == 'h':
        human_score += computer_turn(computer_score)
    else:
        print("Invalid input. Please enter 'r' or 'h.")

if human_score >= 100:
    print("Congratulations! You win!")
else:
    print("Computer wins!")

