# Function to count vowels and consonants in a string
def count_vowels_and_consonants(input_string):
    vowels = "AEIOUaeiou"
    vowel_count = 0
    consonant_count = 0

    for char in input_string:
        if char in vowels:
            vowel_count += 1
        elif char.isalpha():
            consonant_count += 1

    return vowel_count, consonant_count

user_input = input("Enter a string: ")
vowel_count, consonant_count = count_vowels_and_consonants(user_input)
print(f"The number of vowels is {vowel_count}")
print(f"The number of consonants is {consonant_count}")
