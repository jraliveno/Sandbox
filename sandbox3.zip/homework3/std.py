import math

# enter 10 numbers
numbers = []
for i in range(10):
    while True:
        try:
            num = float(input(f"Enter number {i + 1}: "))
            numbers.append(num)
            break
        except ValueError:
            print("Invalid input. Please enter a number.")

# calculate mean
mean = sum(numbers) / len(numbers)

# standard dev.
squared_differences = [(x - mean) ** 2 for x in numbers]
variance = sum(squared_differences) / (len(numbers) - 1)
std_deviation = math.sqrt(variance)

# show the results
print(f"Mean: {mean}")
print(f"Standard Deviation: {std_deviation}")
