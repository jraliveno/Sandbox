import turtle

# size
n = 10

# creating an instance of the turtle
turtle.dot(10,"red")


# loop to draw a side
for i in range(n * 4):
    # drawing side of length i*10
    turtle.forward(i * 10)

    # see if it's a right-side corner (90 degrees) and a multiple of 3
    if i % 4 == 0 and i > 0 and i % 12 == 0:
        turtle.dot(10, "red")  # Add a red dot

    # changing direction of pen by 90 degrees in clockwise
    turtle.right(90)

# close
turtle.done()

