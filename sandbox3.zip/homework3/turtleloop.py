import turtle

screen = turtle.Screen()
screen.bgcolor("white")

turtle = turtle.Turtle()
turtle.speed(5)  # Set the drawing speed

# function for star
def draw_star():
    for _ in range(5):
        turtle.forward(50)
        turtle.right(144)

# Draw three rows of two stars
for _ in range(3):
    for _ in range(2):
        draw_star()
        turtle.penup()
        turtle.forward(70)  # Move to the next position
        turtle.pendown()
    turtle.penup()
    turtle.goto(0, turtle.ycor() - 70)  # Move to the next row
    turtle.pendown()


