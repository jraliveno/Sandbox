# Function to find the largest common prefix between two strings
def find_largest_common_prefix(str1, str2):
    common_prefix = []
    min_length = min(len(str1), len(str2))

    for i in range(min_length):
        if str1[i] == str2[i]:
            common_prefix.append(str1[i])
        else:
            break

    if common_prefix:
        return "".join(common_prefix)
    else:
        return None

# Main program
first_string = input("Enter the first string: ")
second_string = input("Enter the second string: ")

common_prefix = find_largest_common_prefix(first_string, second_string)

if common_prefix:
    print(f"The common prefix is {common_prefix}")
else:
    print(f"{first_string} and {second_string} have no common prefix")
