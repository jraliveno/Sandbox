def rectangle_connection(rect1, rect2):
    x1_rect1, y1_rect1, x2_rect1, y2_rect1 = rect1
    x1_rect2, y1_rect2, x2_rect2, y2_rect2 = rect2

# Check if one rectangle is completely inside the other
    if (x1_rect1 <= x1_rect2 and x2_rect1 >= x2_rect2 and
            y1_rect1 <= y1_rect2 and y2_rect1 >= y2_rect2):
        return "One rectangle is completely inside the other."

    if (x1_rect2 <= x1_rect1 and x2_rect2 >= x2_rect1 and
            y1_rect2 <= y1_rect1 and y2_rect2 >= y2_rect1):
        return "One rectangle is completely inside the other."

# Check if the rectangles overlap
    if (x1_rect1 < x2_rect2 and x2_rect1 > x1_rect2 and
            y1_rect1 < y2_rect2 and y2_rect1 > y1_rect2):
        return "Rectangles overlap."

# Rectangles will not overlap if none of the above conditions are met
    return "Rectangles do not overlap."


# Get user input for the coordinates of two rectangles
try:
    print("Enter the coordinates for Rectangle 1:")
    x1_rect1 = float(input("X1: "))
    y1_rect1 = float(input("Y1: "))
    x2_rect1 = float(input("X2: "))
    y2_rect1 = float(input("Y2: "))

    print("\nEnter the coordinates for Rectangle 2:")
    x1_rect2 = float(input("X1: "))
    y1_rect2 = float(input("Y1: "))
    x2_rect2 = float(input("X2: "))
    y2_rect2 = float(input("Y2: "))

    rect1 = (x1_rect1, y1_rect1, x2_rect1, y2_rect1)
    rect2 = (x1_rect2, y1_rect2, x2_rect2, y2_rect2)

    result = rectangle_connection(rect1, rect2)
    print("\n" + result)
except ValueError:
    print("Invalid input. Please enter valid numeric values for coordinates.")
