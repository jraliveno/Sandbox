def integer_to_roman(num):
    roman_numerals = {
        1: 'I',
        2: 'II',
        3: 'III',
        4: 'IV',
        5: 'V',
        6: 'VI',
        7: 'VII',
        8: 'VIII',
        9: 'IX',
        10: 'X',
    }

    return roman_numerals.get(num, "Invalid input")

try:
    user_input = int(input("Enter an integer between 1 and 10: "))

    if 1 <= user_input <= 10:
        roman_numeral = integer_to_roman(user_input)
        print(f"The Roman numeral equivalent of {user_input} is {roman_numeral}.")
    else:
        print("Number out of range. Enter a number between 1 and 10.")
except ValueError:
    print("Invalid input. Please enter a valid integer.")
