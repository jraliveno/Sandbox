# Runner names and times
runner_names = []
runner_times = []

# Function to get a valid non-negative time input
def get_non_negative_float(prompt):
    while True:
        try:
            value = float(input(prompt))
            if value < 0:
                print("Please enter a non-negative time.")
                continue
            return value
        except ValueError:
            print("Invalid input. Please enter a valid non-negative number.")

# Get runner information
for i in range(3):
    name = input(f"Enter the name of runner {i + 1}: ")
    time = get_non_negative_float(f"Enter the time (in seconds) for {name}: ")

    runner_names.append(name)
    runner_times.append(time)

# Placings
sorted_runners = sorted(zip(runner_names, runner_times), key=lambda x: x[1])

# Order of placings
first_place, second_place, third_place = sorted_runners

# Output the results
print(f"First place: {first_place[0]} with a time of {first_place[1]} seconds")
print(f"Second place: {second_place[0]} with a time of {second_place[1]} seconds")
print(f"Third place: {third_place[0]} with a time of {third_place[1]} seconds")
