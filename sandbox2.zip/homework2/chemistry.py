# Define a dictionary with substance data
substances = {
    "Ethyl Alcohol": {"Freezing Point": -173, "Boiling Point": 172},
    "Mercury": {"Freezing Point": -38, "Boiling Point": 676},
    "Oxygen": {"Freezing Point": -362, "Boiling Point": -306},
    "Water": {"Freezing Point": 32, "Boiling Point": 212},
}

# Get user input for the temperature
try:
    temperature = float(input("Enter a temperature in degrees Fahrenheit: "))

    # Initialize lists to store substances that freeze and boil at the given temperature
    freeze_list = []
    boil_list = []

# Check each substance's freezing and boiling points
    for substance, data in substances.items():
        if temperature <= data["Freezing Point"]:
            freeze_list.append(substance)
        if temperature >= data["Boiling Point"]:
            boil_list.append(substance)

# Output the results
    if freeze_list:
        print(f"The following substances will freeze at {temperature} degrees Fahrenheit: {', '.join(freeze_list)}")
    else:
        print(f"No substances will freeze at {temperature} degrees Fahrenheit.")

    if boil_list:
        print(f"The following substances will boil at {temperature} degrees Fahrenheit: {', '.join(boil_list)}")
    else:
        print(f"No substances will boil at {temperature} degrees Fahrenheit.")
except ValueError:
    print("Invalid input. Please enter a valid temperature.")
