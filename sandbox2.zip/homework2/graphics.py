import turtle

# Function to draw a polygon with certain number of sides and side_length
def draw_polygon(n, side_length):
    angle = 360 / n  # Calculate the angle for each side

    for _ in range(n):
        turtle.forward(side_length)
        turtle.left(angle)

# Input validation function
def get_valid_input(prompt, min_value, max_value):
    while True:
        try:
            value = int(input(prompt))
            if min_value <= value <= max_value:
                return value
            else:
                print(f"Please enter a value between {min_value} and {max_value}.")
        except ValueError:
            print("Invalid input. Please enter an integer.")

screen = turtle.Screen()
screen.title("Shape Drawer")

# Get the number of sides and side length from the user
num_sides = get_valid_input("Enter the number of sides (3-8): ", 3, 8)
side_length = get_valid_input("Enter the length of each side: ", 1, 100)

# Create a Turtle object
shape_drawer = turtle.Turtle()

# Set the drawing speed and draw the shape
shape_drawer.speed(1)  # Adjust the speed as needed
shape_drawer.penup()
shape_drawer.goto(-50, 0)
shape_drawer.pendown()

# Draw the shape based on the number of sides
if num_sides == 3:
    shape_name = "Triangle"
elif num_sides == 4:
    shape_name = "Square"
elif num_sides == 5:
    shape_name = "Pentagon"
elif num_sides == 6:
    shape_name = "Hexagon"
elif num_sides == 7:
    shape_name = "Heptagon"
elif num_sides == 8:
    shape_name = "Octagon"
else:
    shape_name = "Polygon"

print(f"Drawing a {shape_name} with {num_sides} sides and side length {side_length}.")
draw_polygon(num_sides, side_length)

# Close the Turtle graphics window when clicked
screen.exitonclick()
