def zellers_convergence(year, month, day):
    # Adjust the month and year for January and February
    if month <= 2:
        month += 12
        year -= 1

# Calculate the day of the week (0 = Saturday, 1 = Sunday, ..., 6 = Friday)
    h = (day + (13 * (month + 1)) // 5 + year + (year // 4) - (year // 100) + (year // 400)) % 7

# Define the days of the week
    days_of_week = ["Saturday", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday"]

    return days_of_week[h]

# Get input for year, month, and day of the month
try:
    year = int(input("Enter the year (e.g., 2023): "))
    month = int(input("Enter the month (1-12): "))
    day = int(input("Enter the day of the month (1-31): "))

    # Check for valid input
    if 1 <= month <= 12 and 1 <= day <= 31:
        day_of_week = zellers_convergence(year, month, day)
        print(f"The day of the week for {month}/{day}/{year} is {day_of_week}.")
    else:
        print("Invalid input. Please enter valid year, month, and day values.")
except ValueError:
    print("Invalid input. Please enter valid numeric values for year, month, and day.")